# Murang'a County Public Service Request System

A mini eCitizen-style web app built with Python, Flask, Flask-SQLAlchemy and SQLite.

## Features

- Citizen registration and login with hashed passwords
- Submit service requests with category, location, description and optional image
- Citizen dashboard for tracking personal requests
- Admin dashboard with request totals and status counts
- Admin status updates: Pending, In Progress and Resolved
- Filter requests by status
- Responsive interface for laptop and mobile screens

## Requirements

- Python 3.10 or newer
- pip

## Run locally on Windows

1. Install Python from https://www.python.org/downloads/ and tick **Add Python to PATH** during installation.
2. Open Command Prompt in this project folder.
3. Create a virtual environment:

   ```bash
   py -m venv .venv
   ```

4. Activate it:

   ```bash
   .venv\Scripts\activate
   ```

5. Install dependencies:

   ```bash
   python -m pip install -r requirements.txt
   ```

6. Start the app:

   ```bash
   python app.py
   ```

7. Open http://127.0.0.1:5000 in your browser.

The SQLite database is created automatically on first run.

## Create an administrator

For a local demo, first register a normal account. Then open a Python shell in the project folder:

```bash
python
```

Run:

```python
from app import app, db, User
with app.app_context():
    user = User.query.filter_by(email="your-email@example.com").first()
    user.is_admin = True
    db.session.commit()
exit()
```

Replace `your-email@example.com` with the account you registered. Log out and log in again, then open `/admin`.

## Deployment notes

Before public deployment:
- Set a strong random `SECRET_KEY` environment variable.
- Use HTTPS and a production WSGI server such as Gunicorn.
- Use a persistent database and persistent storage for uploads.
- Add CSRF protection, rate limiting, backups, and an explicit privacy/data-retention policy.
- Never deploy Flask's development server or `debug=True` to production.
- Create the administrator securely through a one-time setup command or deployment process; do not expose a public admin-registration option.

## Project structure

```text
muranga_service_request_system/
├── app.py
├── requirements.txt
├── README.md
├── .gitignore
├── templates/
│   ├── base.html
│   ├── index.html
│   ├── register.html
│   ├── login.html
│   ├── dashboard.html
│   ├── new_request.html
│   ├── admin.html
│   └── error.html
└── static/
    ├── style.css
    └── uploads/
```
