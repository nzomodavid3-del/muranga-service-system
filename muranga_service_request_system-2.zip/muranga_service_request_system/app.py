import os
from functools import wraps
from flask import Flask, render_template, request, redirect, url_for, flash, session, abort
from werkzeug.security import generate_password_hash, check_password_hash
from werkzeug.utils import secure_filename
from flask_sqlalchemy import SQLAlchemy

BASE_DIR = os.path.abspath(os.path.dirname(__file__))
UPLOAD_FOLDER = os.path.join(BASE_DIR, "static", "uploads")
ALLOWED_EXTENSIONS = {"png", "jpg", "jpeg", "gif", "webp"}

app = Flask(__name__)
app.config["SECRET_KEY"] = os.environ.get("SECRET_KEY", "change-this-secret-key-before-deployment")
app.config["SQLALCHEMY_DATABASE_URI"] = "sqlite:///" + os.path.join(BASE_DIR, "service_requests.db")
app.config["SQLALCHEMY_TRACK_MODIFICATIONS"] = False
app.config["UPLOAD_FOLDER"] = UPLOAD_FOLDER
app.config["MAX_CONTENT_LENGTH"] = 5 * 1024 * 1024

db = SQLAlchemy(app)
os.makedirs(UPLOAD_FOLDER, exist_ok=True)

CATEGORIES = [
    "Roads and drainage", "Water supply", "Garbage collection",
    "Street lighting", "Public health", "Other"
]
STATUSES = ["Pending", "In Progress", "Resolved"]


class User(db.Model):
    id = db.Column(db.Integer, primary_key=True)
    full_name = db.Column(db.String(120), nullable=False)
    email = db.Column(db.String(160), unique=True, nullable=False, index=True)
    password_hash = db.Column(db.String(255), nullable=False)
    is_admin = db.Column(db.Boolean, default=False, nullable=False)
    requests = db.relationship("ServiceRequest", backref="citizen", lazy=True)

    def set_password(self, password):
        self.password_hash = generate_password_hash(password)

    def check_password(self, password):
        return check_password_hash(self.password_hash, password)


class ServiceRequest(db.Model):
    id = db.Column(db.Integer, primary_key=True)
    category = db.Column(db.String(80), nullable=False)
    location = db.Column(db.String(200), nullable=False)
    description = db.Column(db.Text, nullable=False)
    image_filename = db.Column(db.String(255))
    status = db.Column(db.String(30), default="Pending", nullable=False)
    created_at = db.Column(db.DateTime, server_default=db.func.now(), nullable=False)
    user_id = db.Column(db.Integer, db.ForeignKey("user.id"), nullable=False)


def current_user():
    user_id = session.get("user_id")
    return db.session.get(User, user_id) if user_id else None


@app.context_processor
def inject_user():
    return {"current_user": current_user(), "categories": CATEGORIES, "statuses": STATUSES}


def login_required(view):
    @wraps(view)
    def wrapped(*args, **kwargs):
        if not current_user():
            flash("Please log in to continue.", "warning")
            return redirect(url_for("login"))
        return view(*args, **kwargs)
    return wrapped


def admin_required(view):
    @wraps(view)
    def wrapped(*args, **kwargs):
        user = current_user()
        if not user:
            flash("Please log in first.", "warning")
            return redirect(url_for("login"))
        if not user.is_admin:
            abort(403)
        return view(*args, **kwargs)
    return wrapped


def allowed_file(filename):
    return "." in filename and filename.rsplit(".", 1)[1].lower() in ALLOWED_EXTENSIONS


@app.route("/")
def index():
    total = ServiceRequest.query.count()
    resolved = ServiceRequest.query.filter_by(status="Resolved").count()
    open_count = total - resolved
    recent = ServiceRequest.query.order_by(ServiceRequest.created_at.desc()).limit(3).all()
    return render_template("index.html", total=total, resolved=resolved, open_count=open_count, recent=recent)


@app.route("/register", methods=["GET", "POST"])
def register():
    if current_user():
        return redirect(url_for("dashboard"))
    if request.method == "POST":
        name = request.form.get("full_name", "").strip()
        email = request.form.get("email", "").strip().lower()
        password = request.form.get("password", "")
        if not name or not email or len(password) < 8:
            flash("Enter your name and email, and use a password of at least 8 characters.", "danger")
            return render_template("register.html")
        if User.query.filter_by(email=email).first():
            flash("An account with that email already exists.", "danger")
            return render_template("register.html")
        user = User(full_name=name, email=email)
        user.set_password(password)
        db.session.add(user)
        db.session.commit()
        session["user_id"] = user.id
        flash("Account created successfully. You can now submit a request.", "success")
        return redirect(url_for("dashboard"))
    return render_template("register.html")


@app.route("/login", methods=["GET", "POST"])
def login():
    if request.method == "POST":
        email = request.form.get("email", "").strip().lower()
        password = request.form.get("password", "")
        user = User.query.filter_by(email=email).first()
        if user and user.check_password(password):
            session.clear()
            session["user_id"] = user.id
            flash("Welcome back.", "success")
            return redirect(url_for("admin_dashboard" if user.is_admin else "dashboard"))
        flash("Incorrect email or password.", "danger")
    return render_template("login.html")


@app.route("/logout")
def logout():
    session.clear()
    flash("You have been logged out.", "info")
    return redirect(url_for("index"))


@app.route("/dashboard")
@login_required
def dashboard():
    user = current_user()
    requests_list = ServiceRequest.query.filter_by(user_id=user.id).order_by(ServiceRequest.created_at.desc()).all()
    return render_template("dashboard.html", requests_list=requests_list)


@app.route("/requests/new", methods=["GET", "POST"])
@login_required
def new_request():
    if request.method == "POST":
        category = request.form.get("category", "")
        location = request.form.get("location", "").strip()
        description = request.form.get("description", "").strip()
        image_filename = None
        image = request.files.get("image")

        if category not in CATEGORIES or not location or not description:
            flash("Please complete all required fields.", "danger")
            return render_template("new_request.html")
        if len(location) > 200 or len(description) > 5000:
            flash("Location or description is too long.", "danger")
            return render_template("new_request.html")
        if image and image.filename:
            if not allowed_file(image.filename):
                flash("Image must be PNG, JPG, JPEG, GIF or WEBP.", "danger")
                return render_template("new_request.html")
            safe_name = secure_filename(image.filename)
            image_filename = f"{current_user().id}_{os.urandom(6).hex()}_{safe_name}"
            image.save(os.path.join(app.config["UPLOAD_FOLDER"], image_filename))

        service_request = ServiceRequest(
            category=category, location=location, description=description,
            image_filename=image_filename, user_id=current_user().id
        )
        db.session.add(service_request)
        db.session.commit()
        flash(f"Request #{service_request.id} submitted successfully.", "success")
        return redirect(url_for("dashboard"))
    return render_template("new_request.html")


@app.route("/admin")
@admin_required
def admin_dashboard():
    status_filter = request.args.get("status", "")
    query = ServiceRequest.query
    if status_filter in STATUSES:
        query = query.filter_by(status=status_filter)
    requests_list = query.order_by(ServiceRequest.created_at.desc()).all()
    total = ServiceRequest.query.count()
    resolved = ServiceRequest.query.filter_by(status="Resolved").count()
    in_progress = ServiceRequest.query.filter_by(status="In Progress").count()
    pending = ServiceRequest.query.filter_by(status="Pending").count()
    return render_template(
        "admin.html", requests_list=requests_list, total=total,
        resolved=resolved, in_progress=in_progress, pending=pending,
        status_filter=status_filter
    )


@app.route("/admin/request/<int:request_id>/status", methods=["POST"])
@admin_required
def update_status(request_id):
    service_request = db.get_or_404(ServiceRequest, request_id)
    new_status = request.form.get("status", "")
    if new_status not in STATUSES:
        flash("Invalid status selected.", "danger")
    else:
        service_request.status = new_status
        db.session.commit()
        flash(f"Request #{service_request.id} updated to {new_status}.", "success")
    return redirect(url_for("admin_dashboard"))


@app.errorhandler(403)
def forbidden(_error):
    return render_template("error.html", code=403, message="You do not have permission to view this page."), 403


@app.errorhandler(404)
def not_found(_error):
    return render_template("error.html", code=404, message="The page or request was not found."), 404


with app.app_context():
    db.create_all()


if __name__ == "__main__":
    app.run(debug=True)
